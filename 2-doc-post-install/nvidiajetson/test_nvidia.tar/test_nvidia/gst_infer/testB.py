#!/usr/bin/env python3

#import sys
#sys.path.append('/usr/lib/python3.6')
#sys.path.append('/opt/nvidia/deepstream/deepstream/sources/deepstream_python_apps/apps/bindings/jetson')
#sys.path.append('/opt/nvidia/deepstream/deepstream/sources/deepstream_python_apps/apps')
#sys.path.append('.')

import gi
gi.require_version('Gst', '1.0')
from gi.repository import GObject, Gst

def bus_call(self, bus, message):
    print("bus_call")

def osd_sink_pad_buffer_probe(pad,info,u_data):
    print("osd_sink_pad_buffer_probe")


if __name__ == "__main__":

    #sys.path.append('.')

    # Standard GStreamer initialization
    GObject.threads_init()
    Gst.init(None)

    # Create gstreamer elements
    # Create Pipeline element that will form a connection of other elements
    print("Creating Pipeline \n ")
    pipeline = Gst.Pipeline()

    if not pipeline:
        sys.stderr.write(" Unable to create Pipeline \n")

    # Source element for reading from the file
    print("Creating Source \n ")
    source = Gst.ElementFactory.make("nvarguscamerasrc", "src-elem")
    if not source:
        sys.stderr.write(" Unable to create Source \n")

    # Converter to scale the image
    nvvidconv_src = Gst.ElementFactory.make("nvvideoconvert", "convertor_src")
    if not nvvidconv_src:
        sys.stderr.write(" Unable to create nvvidconv_src \n")

    # Caps for NVMM and resolution scaling
    caps_nvvidconv_src = Gst.ElementFactory.make("capsfilter", "nvmm_caps")
    if not caps_nvvidconv_src:
        sys.stderr.write(" Unable to create capsfilter \n")

    # Create nvstreammux instance to form batches from one or more sources.
    streammux = Gst.ElementFactory.make("nvstreammux", "Stream-muxer")
    if not streammux:
        sys.stderr.write(" Unable to create NvStreamMux \n")

    # Use nvinfer to run inferencing on decoder's output,
    # behaviour of inferencing is set through config file
    pgie = Gst.ElementFactory.make("nvinfer", "primary-inference")
    if not pgie:
        sys.stderr.write(" Unable to create pgie \n")

#    tracker = Gst.ElementFactory.make("nvtracker", "tracker")
#    if not tracker:
#        sys.stderr.write(" Unable to create tracker \n")
#
#    sgie1 = Gst.ElementFactory.make("nvinfer", "secondary1-nvinference-engine")
#    if not sgie1:
#        sys.stderr.write(" Unable to make sgie1 \n")
#
#    sgie2 = Gst.ElementFactory.make("nvinfer", "secondary2-nvinference-engine")
#    if not sgie1:
#        sys.stderr.write(" Unable to make sgie2 \n")
#
#    sgie3 = Gst.ElementFactory.make("nvinfer", "secondary3-nvinference-engine")
#    if not sgie3:
#        sys.stderr.write(" Unable to make sgie3 \n")

    nvvidconv = Gst.ElementFactory.make("nvvideoconvert", "convertor")
    if not nvvidconv:
        sys.stderr.write(" Unable to create nvvidconv \n")

    # Create OSD to draw on the converted RGBA buffer
    nvosd = Gst.ElementFactory.make("nvdsosd", "onscreendisplay")

    if not nvosd:
        sys.stderr.write(" Unable to create nvosd \n")

    # Finally render the osd output
    #if is_aarch64():
    #    transform = Gst.ElementFactory.make("nvegltransform", "nvegl-transform")

    print("Creating EGLSink \n")
    sink = Gst.ElementFactory.make("nveglglessink", "nvvideo-renderer")
    if not sink:
       sys.stderr.write(" Unable to create egl sink \n")

    source.set_property('bufapi-version', True)

    caps_nvvidconv_src.set_property('caps', Gst.Caps.from_string('video/x-raw(memory:NVMM), width=1280, height=720'))

    streammux.set_property('width', 1280)
    streammux.set_property('height', 720)
    streammux.set_property('batch-size', 1)
    streammux.set_property('batched-push-timeout', 4000000)

#    #Set properties of pgie and sgie
    pgie.set_property('config-file-path', "deepstream-rtsp.cfg")
#    sgie1.set_property('config-file-path', "dstest1_pgie_config.txt.txt")
#    sgie2.set_property('config-file-path', "dstest1_pgie_config.txt.txt")
#    sgie3.set_property('config-file-path', "dstest1_pgie_config.txt.txt")
#
#    #Set properties of tracker
#    config = configparser.ConfigParser()
#    config.read('dstest1_pgie_config.txt')
#    config.sections()
#
#    for key in config['tracker']:
#        if key == 'tracker-width' :
#            tracker_width = config.getint('tracker', key)
#            tracker.set_property('tracker-width', tracker_width)
#        if key == 'tracker-height' :
#            tracker_height = config.getint('tracker', key)
#            tracker.set_property('tracker-height', tracker_height)
#        if key == 'gpu-id' :
#            tracker_gpu_id = config.getint('tracker', key)
#            tracker.set_property('gpu_id', tracker_gpu_id)
#        if key == 'll-lib-file' :
#            tracker_ll_lib_file = config.get('tracker', key)
#            tracker.set_property('ll-lib-file', tracker_ll_lib_file)
#        if key == 'll-config-file' :
#            tracker_ll_config_file = config.get('tracker', key)
#            tracker.set_property('ll-config-file', tracker_ll_config_file)
#        if key == 'enable-batch-process' :
#            tracker_enable_batch_process = config.getint('tracker', key)
#            tracker.set_property('enable_batch_process', tracker_enable_batch_process)

    print("Adding elements to Pipeline \n")
    pipeline.add(source)
    pipeline.add(nvvidconv_src)
    pipeline.add(caps_nvvidconv_src)
    pipeline.add(streammux)
    pipeline.add(pgie)
#    pipeline.add(tracker)
#    pipeline.add(sgie1)
#    pipeline.add(sgie2)
#    pipeline.add(sgie3)
    pipeline.add(nvvidconv)
    pipeline.add(nvosd)
    pipeline.add(sink)
#    if is_aarch64():
#        pipeline.add(transform)

    # we link the elements together
    print("Linking elements in the Pipeline \n")
    source.link(nvvidconv_src)
    nvvidconv_src.link(caps_nvvidconv_src)

    sinkpad = streammux.get_request_pad("sink_0")
    if not sinkpad:
        sys.stderr.write(" Unable to get the sink pad of streammux \n")
    srcpad = caps_nvvidconv_src.get_static_pad("src")
    if not srcpad:
        sys.stderr.write(" Unable to get source pad of source \n")
    srcpad.link(sinkpad)
    streammux.link(pgie)
    pgie.link(nvvidconv)
#    pgie.link(tracker)
#    tracker.link(sgie1)
#    sgie1.link(sgie2)
#    sgie2.link(sgie3)
#    sgie3.link(nvvidconv)
    nvvidconv.link(nvosd)
#    if is_aarch64():
#        nvosd.link(transform)
#        transform.link(sink)
#    else:
    nvosd.link(sink)


    # create and event loop and feed gstreamer bus mesages to it
    loop = GObject.MainLoop()

    bus = pipeline.get_bus()
    bus.add_signal_watch()
    bus.connect ("message", bus_call, loop)

    # Lets add probe to get informed of the meta data generated, we add probe to
    # the sink pad of the osd element, since by that time, the buffer would have
    # had got all the metadata.
    osdsinkpad = nvosd.get_static_pad("sink")
    if not osdsinkpad:
        sys.stderr.write(" Unable to get sink pad of nvosd \n")
    osdsinkpad.add_probe(Gst.PadProbeType.BUFFER, osd_sink_pad_buffer_probe, 0)


    print("Starting pipeline \n")

    # start play back and listed to events
    pipeline.set_state(Gst.State.PLAYING)
    try:
      loop.run()
    except:
      pass

    # cleanup
    pipeline.set_state(Gst.State.NULL)
