#!/bin/bash

export CAM_WIDTH="1280"
export CAM_HEIGHT="720"
export CAM_MAT="8.9712590160498451e+02 0. 5.9290793586019208e+02 0. 8.7139246526095974e+02 3.5323728389070351e+02 0. 0. 1."
export CAM_DIS="1.6729349667635585e-01 -1.8283939851950195e+00 -3.8236989961622351e-03 -1.7858415775001007e-02 3.9122153603756376e+00"

gst-launch-1.0 nvarguscamerasrc \
    ! 'video/x-raw(memory:NVMM), format=NV12, width=1280, height=720, framerate=30/1' \
    ! tee name=streams \
    ! nvv4l2h264enc insert-sps-pps=true bitrate=2000000 \
    ! h264parse  \
    ! rtph264pay name=pay0 pt=96 config-interval=1 \
    ! queue max-size-buffers=0 max-size-time=0 max-size-bytes=0 \
    ! udpsink host=192.168.3.1 port=5700 streams. \
    ! nvivafilter cuda-process=true customer-lib-name=lib-gst-custom-opencv_cudaprocess.so \
    ! 'video/x-raw(memory:NVMM), format=RGBA' \
    ! nvvidconv \
    ! nvv4l2h264enc insert-sps-pps=true bitrate=2000000 \
    ! h264parse  \
    ! rtph264pay name=pay1 pt=96 config-interval=1 \
    ! queue max-size-buffers=0 max-size-time=0 max-size-bytes=0 \
    ! udpsink host=192.168.3.1 port=5600
